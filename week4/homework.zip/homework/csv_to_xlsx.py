import sys
#importme
src_file = sys.argv[1]
tgt_file = sys.argv[2]

#createme
#callme

print "Success!"
