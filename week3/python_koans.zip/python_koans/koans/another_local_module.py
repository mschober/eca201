#!/usr/bin/env python
# -*- coding: utf-8 -*-


class Goose(object):
    @property
    def name(self):
        return "Mr Stabby"


class Hamster(object):
    @property
    def name(self):
        return "Phil"


class _SecretSquirrel(object):
    @property
    def name(self):
        return "Mr Anonymous"
